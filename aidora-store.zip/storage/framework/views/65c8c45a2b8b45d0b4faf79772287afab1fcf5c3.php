

<?php $__env->startSection('content'); ?>
<section id="barang-dashboard">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h4><b>Kelola Product</b></h4>
            </div><!--card-header-->
            <div class="card-body">

            <!-- Button trigger modal -->
            <button type="button" class="btn btn-success mb-3"  data-toggle="modal" data-target="#modalTambahProduct">
                Tambah Product
            </button>
            
            <!-- Modal -->
            <div class="modal fade" id="modalTambahProduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><b>Tambah Product</b></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo e(Form::open(['id'=>'formTambahProduct','route' => 'products.store'])); ?>

                                <?php echo e(Form::label('Product Name :')); ?>

                                <?php echo e(Form::text('product_name','',['class'=>'form-control form-group','placeholder'=>'','required'])); ?>

                                <?php echo e(Form::label('id_type','Tipe :')); ?>

                                <select name="id_type" class="form-control form-group">
                                    <?php $__currentLoopData = $dataType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dtt->id_type); ?>" class="form-control"><?php echo e($dtt->type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php echo e(Form::label('Base Price :')); ?>

                                <?php echo e(Form::text('base_price','',['class'=>'form-control form-group uangBarang','placeholder'=>'','required'])); ?>

                                <?php echo e(Form::label('Sell Price :')); ?>

                                <?php echo e(Form::text('sell_price','',['class'=>'form-control form-group uangBarang','placeholder'=>'','required'])); ?>

                                <?php echo e(Form::label('Description :')); ?>

                                <?php echo e(Form::textarea('description','',['class'=>'form-control form-group','placeholder'=>'','required'])); ?>

                                <?php echo e(Form::submit('Simpan',['class'=>'btn btn-success btn-block'])); ?>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div><!--modal-content-->
                </div><!--modal-dialog-->
            </div><!--modal-fade-->

                <table id="tabel-products" class="table table-bordered dt-responsive nowrap" style="width:100%">
                    <thead>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Product Type</th>
                        <th>Base Price</th>
                        <th>Sell Price</th>
                        <th>Description</th>
                        <th>Aksi</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dp->id_product); ?></td>
                                <td><?php echo e($dp->product_name); ?></td>
                                <td><?php echo e($dp->type); ?></td>
                                <td><?php echo e(number_format($dp->sell_price, 2)); ?></td>
                                <td><?php echo e(number_format($dp->base_price, 2)); ?></td>
                                <td><?php echo e($dp->description); ?></td>
                                <td>
                                    <a class="btn btn-success btn-sm" style="color:#fff;" data-toggle="modal" data-target="#edit-product-modal<?php echo e($dp->id_product); ?>">Edit</a>
                                </td>
                                <td>
                                    <?php echo Form::open(['route'=>['manage.product-images', $dp->id_product], 'method'=>'GET']); ?>

                                        <?php echo e(Form::hidden('id_product',"$dp->id_product")); ?>

                                        <?php echo e(Form::submit('Kelola Gambar',['class'=>'btn btn-success btn-block btn-sm'])); ?>

                                    <?php echo Form::close(); ?>

                                </td>          
                            </tr>
                            <!-- Modal Edit Tagihan Pembayaran-->
                            <div class="modal fade" id="edit-product-modal<?php echo e($dp->id_product); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h2>Form Edit Product</h2>   
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        </div>
                                        <div class="modal-body">
                                        <?php echo Form::open(['route'=>['products.update', $dp->id_product], 'method'=>'PUT']); ?>

                                            <?php echo e(Form::label('id_product','Id Product : ')); ?>

                                            <p><b><?php echo e($dp->id_product); ?></b></p>
                                            <?php echo e(Form::label('Product Name :')); ?>

                                            <?php echo e(Form::text('product_name',$dp->product_name,['class'=>'form-control form-group','placeholder'=>'','required'])); ?>

                                            <?php echo e(Form::label('id_type','Tipe :')); ?>

                                            <select name="id_type" class="form-control form-group">
                                                <?php $__currentLoopData = $dataType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($dtt->id_type == $dp->id_type): ?>
                                                        <option value="<?php echo e($dtt->id_type); ?>" class="form-control" selected><?php echo e($dtt->type); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($dtt->id_type); ?>" class="form-control"><?php echo e($dtt->type); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php echo e(Form::label('Base Price :')); ?>

                                            <?php echo e(Form::text('base_price',$dp->base_price,['class'=>'form-control form-group','placeholder'=>'','required'])); ?>

                                            <?php echo e(Form::label('Sell Price :')); ?>

                                            <?php echo e(Form::text('sell_price',$dp->sell_price,['class'=>'form-control form-group','placeholder'=>'','required'])); ?>

                                            <?php echo e(Form::label('Desciption: ')); ?>

                                            <?php echo e(Form::textarea('description','',['class'=>'form-control form-group','placeholder'=>'','required'])); ?>

                                            <?php echo e(Form::submit('Simpan',['class'=>'btn btn-success btn-block'])); ?>

                                        <?php echo e(Form::close()); ?>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Modal Edit Tagihan Pembayaran-->   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div><!--card-body-->
        </div><!--card-->
    </div><!--container-->
    <script>
        $(document).ready(function() {
            $('#tabel-products').DataTable();
        } );
    </script>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aidora-store\resources\views\admin\products.blade.php ENDPATH**/ ?>