<?php $__env->startSection('content'); ?>
<section id="hero">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-12 col-lg-8 col-xl-6 text-center">
        <img alt="image" width="200" src="resources/logo/aidora-logo.png">
        <h1>Fashion and Beauty Products</h1>
      </div><!--end col-->
    </div><!--end row-->
  </div><!--end container-->
</section>

<section id="featured">
    <div class="row text-center justify-content-center mt-5 pr-3 pl-3">
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
        <div class="layer card-bg-image-clothes">
          <a href="#">
            <div class="card">
              <h3><strong>Woman Fashion</strong></h3>
            </div><!--card-->
          </a><!--end link-->
        </div><!--layer-->
      </div><!--col-->

      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
        <div class="layer card-bg-image-bags">
          <a href="#">
            <div class="card">
              <h3><strong>Woman Bags</strong></h3>
            </div><!--card-->
          </a><!--end link-->
        </div><!--layer-->
      </div><!--col-->

      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
        <div class="layer card-bg-image-acc">
          <a href="#">
            <div class="card">
              <h3><strong>Accessories</strong></h3>
            </div><!--card-->
          </a><!--end link-->
        </div><!--layer-->
      </div><!--col-->

    </div><!--row-->
</section>

<section id="newly-arrived">
    <div class="container-fluid">
        <h3 class="text-center"><b>All Products</b></h3>
        <hr>

          <div class="products">
            <?php $__currentLoopData = $dataProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card" style="width: 18rem;">
                  <?php
                    $product_id=$dp->id_product;
                    $productThumbnail=DB::select(DB::raw("SELECT * FROM product_images WHERE product_images.id_product=$product_id
                    and product_images.orders=1 LIMIT 1"));
                  ?>
                  <?php $__currentLoopData = $productThumbnail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="card-img-top img-responsive" src="<?php echo e(asset('storage/product_images/'.$dp->id_product.'/'.$pt->file)); ?>" alt="<?php echo e($pt->file); ?>"></td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="card-body">
                      <h5 class="card-title"><b><?php echo e($dp->product_name); ?></b></h5>
                      <p class="card-text">Price : Rp. <?php echo e(number_format($dp->sell_price, 0, ',', '.')); ?></p>
                      <a href="#" class="btn btn-primary">Go somewhere</a>
                  </div>
                </div><!--end card-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div><!--carousel-->

    </div><!--end container-->
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aidora-store\resources\views\welcome.blade.php ENDPATH**/ ?>