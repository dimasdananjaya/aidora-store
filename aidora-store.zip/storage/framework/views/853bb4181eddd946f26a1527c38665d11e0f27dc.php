

<?php $__env->startSection('content'); ?>
    <section id="manage-product-images">
        <div class="container">
            <h4 class="text-center"><b>Product : <?php echo e($dataProduct->product_name); ?></b></h4>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary mb-3 d-block mx-auto"  data-toggle="modal" data-target="#modalTambahProduct">
                Add Product Image
            </button>
            
            <!-- Modal -->
            <div class="modal fade" id="modalTambahProduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><b>Add Product Image</b></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo e(Form::open(['id'=>'formTambahProduct','route' => 'product-images.store','files' => true])); ?>

                                <?php echo e(Form::label('File :')); ?>

                                <?php echo e(Form::file('file',['class'=>'form-control-file form-group'])); ?>

                                <?php echo e(Form::label('Image Order :')); ?>

                                <?php echo e(Form::number('orders','',['class'=>'form-control form-group','placeholder'=>'','required'])); ?>

                                <?php echo e(Form::hidden('id_product', $dataProduct->id_product)); ?>

                                <?php echo e(Form::submit('Simpan',['class'=>'btn btn-success btn-block'])); ?>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div><!--modal-content-->
                </div><!--modal-dialog-->
            </div><!--modal-fade-->

            <div class="row">
                <?php $__currentLoopData = $dataProductImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top img-responsive" src="<?php echo e(asset('storage/product_images/'.$dpi->id_product.'/'.$dpi->file)); ?>" alt="<?php echo e($dpi->file); ?>"></td>
                        <div class="card-body">
                            <p>Image Order : <?php echo e($dpi->orders); ?></p>
                            <div class="d-flex flex-row">
                                <div class="p-2">
                                    <a class="btn btn-primary mb-3 d-block mx-auto btn-sm"  data-toggle="modal" data-target="#modalEditProduct<?php echo e($dpi->id_image); ?>">
                                        Edit
                                    </a>
                                </div><!--p2-->    
                                <div class="p-2">
                                    <?php echo Form::open(['route' => ['product-images.destroy', $dpi->id_image],'method' => 'POST']); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <?php echo e(Form::submit("Delete", ['class'=>'btn btn-danger btn-sm'])); ?> 
                                    <?php echo Form::close(); ?>

                                </div><!--p2-->
                            </div>
                        </div>
                    </div><!--card-->

                    <!-- Modal -->
                    <div class="modal fade" id="modalEditProduct<?php echo e($dpi->id_image); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"><b>Edit Product Image</b></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <?php echo Form::open(['route'=>['product-images.update', $dpi->id_image], 'method'=>'PUT', 'files'=>true]); ?>

                                        <?php echo e(Form::label('File :')); ?>

                                        <?php echo e(Form::file('file',['class'=>'form-control-file form-group'])); ?>

                                        <?php echo e(Form::label('Image Order :')); ?>

                                        <?php echo e(Form::number('orders',$dpi->orders,['class'=>'form-control form-group','required'])); ?>

                                        <?php echo e(Form::hidden('id_image', $dpi->id_image)); ?>

                                        <?php echo e(Form::hidden('id_product', $dpi->id_product)); ?>

                                        <?php echo e(Form::hidden('file_lama', $dpi->file)); ?>

                                        <?php echo e(Form::submit('Simpan',['class'=>'btn btn-success btn-block'])); ?>

                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div><!--modal-content-->
                        </div><!--modal-dialog-->
                    </div><!--modal-fade-->
                </div><!--col-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!--carousel-->
        </div><!--container-->
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aidora-store\resources\views\admin\manage-product-images.blade.php ENDPATH**/ ?>